from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import mysql.connector
import hashlib
import base64
from werkzeug.security import check_password_hash
from flask_cors import CORS
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
CORS(app)

# MySQL Connection
try:
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="Sai@123",
        database="preschool_management"
    )
    cursor = db.cursor(dictionary=True)
    print("✅ Successfully connected to MySQL Database!")
except mysql.connector.Error as e:
    print(f"❌ Database Connection Error: {str(e)}")

# Flask-Login Setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

# User Model
class User(UserMixin):
    def __init__(self, id, email, role):
        self.id = id
        self.email = email
        self.role = role

@login_manager.user_loader
def load_user(user_id):
    cursor.execute("SELECT id, email, role FROM users WHERE id = %s", (user_id,))
    user_data = cursor.fetchone()
    if user_data:
        return User(user_data["id"], user_data["email"], user_data["role"])
    return None

# Function to generate a shortened hash
def generate_short_hash(password):
    hashed = hashlib.sha256(password.encode()).digest()
    short_hash = base64.b64encode(hashed).decode()[:8]
    return short_hash

# Ensure password column can store hashed passwords
cursor.execute("ALTER TABLE users MODIFY password VARCHAR(255);")
db.commit()

# Role-Based Access Control (RBAC) Decorators
def teacher_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if current_user.role != "teacher":
            return jsonify({"message": "Unauthorized access!", "status": "error"}), 403
        return f(*args, **kwargs)
    return decorated_function

def student_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if current_user.role != "student":
            return jsonify({"message": "Unauthorized access!", "status": "error"}), 403
        return f(*args, **kwargs)
    return decorated_function

# Routes for Authentication and Dashboards
@app.route('/')
def home():
    return render_template("login.html")

@app.route('/teacher_dashboard')
@login_required
@teacher_required
def teacher_dashboard():
    return render_template("teacher_dashboard.html")

@app.route('/student_dashboard')
@login_required
@student_required
def student_dashboard():
    return render_template("student_dashboard.html")

@app.route('/public_dashboard')
def public_dashboard():
    return render_template("public_dashboard.html")

# Login Route (With Redirect Based on Role)
@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    email = request.form['email']
    password = request.form['password']

    cursor.execute("SELECT id, email, password, role FROM users WHERE email = %s", (email,))
    user_data = cursor.fetchone()

    if user_data:
        stored_password = user_data["password"]

        if stored_password == generate_short_hash(password):
            user = User(user_data["id"], user_data["email"], user_data["role"])
            login_user(user)

            if user.role == "teacher":
                return jsonify({"message": "Login Successful!", "status": "success", "redirect": "/teacher_dashboard"})
            elif user.role == "student":
                return jsonify({"message": "Login Successful!", "status": "success", "redirect": "/student_dashboard"})
            else:
                return jsonify({"message": "Login Successful!", "status": "success", "redirect": "/public_dashboard"})
        else:
            return jsonify({"message": "Incorrect password.", "status": "error"}), 400
    else:
        return jsonify({"message": "User not found.", "status": "error"}), 400

# Announcements Fetch Route
@app.route('/get_announcements', methods=['GET'])
def get_announcements():
    try:
        cursor.execute("SELECT title, content FROM announcements ORDER BY id DESC")
        announcements = cursor.fetchall()

        print(f"🔎 Debug: Fetched Announcements = {announcements}")

        if not announcements:
            return jsonify({"message": "No announcements found.", "status": "empty"})

        return jsonify(announcements)

    except mysql.connector.Error as err:
        print(f"❌ Database Error: {str(err)}")
        return jsonify({"message": "Database error occurred!", "status": "error"}), 500

# Feedback Submission Route
@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    try:
        data = request.get_json()

        if not data or not data.get("email") or not data.get("role") or not data.get("message"):
            return jsonify({"message": "All fields are required!", "status": "error"}), 400

        cursor.execute("SELECT id FROM users WHERE email = %s", (data["email"],))
        user_data = cursor.fetchone()

        if not user_data:
            return jsonify({"message": "Invalid user email!", "status": "error"}), 400

        cursor.execute(
            "INSERT INTO feedback (submitted_by, role, message) VALUES (%s, %s, %s)",
            (user_data["id"], data["role"], data["message"])
        )
        db.commit()

        return jsonify({"message": "Feedback submitted successfully!", "status": "success"})
    except mysql.connector.Error as err:
        print(f"❌ Database Error: {str(err)}")
        return jsonify({"message": "Database error occurred!", "status": "error"}), 500

# CRUD Operations for Teachers
@app.route('/add_announcement', methods=['POST'])
@login_required
@teacher_required
def add_announcement():
    title = request.form['title']
    content = request.form['content']
    cursor.execute("INSERT INTO announcements (title, content, posted_by) VALUES (%s, %s, %s)",
                   (title, content, current_user.id))
    db.commit()
    return jsonify({"message": "Announcement added successfully!", "status": "success"})

# Logout Route
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return jsonify({"message": "You have logged out successfully.", "status": "info"})

# 🕹️ Game Routes
@app.route('/menu')
def menu():
    return render_template('menu.html')

@app.route('/colormatch')
def color_match():
    return render_template('game.html')

@app.route('/shapefinder')
def shape_finder():
    return render_template('shapes.html')

@app.route('/memorymatch')
def memory_match():
    return render_template('memorymatch.html')

@app.route('/animalguess')
def animal_guess():
    return render_template('animalguess.html')

# Run Flask App
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)