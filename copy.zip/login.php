<?php
// Define your credentials
$validEmail = "teacher@example.com";  // Replace with your teacher's email
$validPassword = "password123";        // Replace with your teacher's password

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the email and password from the form
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if credentials match
    if ($email === $validEmail && $password === $validPassword) {
        // Successful login
        header("Location: gallery.html"); // Redirect to the gallery page
        exit();
    } else {
        // Incorrect login credentials
        echo "<script>alert('Invalid email or password.'); window.location.href = 'index.html';</script>";
    }
}
?>
